#Assignment 1 CPSC 314 
Name: Ow Yong Chee Seng
Student Number: 61164992
CWL username: csowyong

To run: 
press the live server button at the bottomright of VScode

To move the Armadillo
- "w" moves the armadillo forward relative to the model
- "s" moves the armadillo backward relative to the model
- "d" moves the armadillo right relative to the model
- "a" moves the armadillo left relative to the model

To rotate the Armadillo 
- "e" rotates the armadillo clockwise relative to the model
- "q" rotates the armadillo counterclockwise relative to the model
