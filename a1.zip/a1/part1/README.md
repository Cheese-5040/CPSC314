# Assignment 1

A1 code for students.
