# Assignment 2 CPSC 314
Name: Ow Yong Chee Seng
Student Number: 61164992
CWL username: csowyong

For both parts: 
To run: 
press the live server button at the bottomright of VScode

To move the sphere
- "w" moves the sphere forward relative to the model
- "s" moves the sphere backward relative to the model
- "d" moves the sphere right relative to the model
- "a" moves the sphere left relative to the model
- "q" moves the sphere down relative to the model
- "e" moves the sphere up relative to the model 

all movements will be shown in console
-"p" prints out the eye position, sphere poisiton and the distance between them 

for part 2: 
- I used a beating heart by distorting the sphere
- I also used a gradient colouring technique to shade the heart to three colours
- I made the heart pulse that looks like heart pulsating (by making the y variable contain the time, and also using a sine function)